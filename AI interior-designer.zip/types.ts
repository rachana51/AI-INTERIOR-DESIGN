
export enum DesignStyle {
  Modern = 'Modern',
  Minimalist = 'Minimalist',
  Scandinavian = 'Scandinavian',
  Bohemian = 'Bohemian',
  Industrial = 'Industrial',
  Coastal = 'Coastal',
}

export interface StyleOption {
  name: DesignStyle;
  icon: JSX.Element;
}

export interface RedesignResult {
  generatedImage: string | null;
  generatedText: string | null;
}
