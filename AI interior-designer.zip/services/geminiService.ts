
import { GoogleGenAI, Modality } from "@google/genai";
import { DesignStyle } from '../types';
import type { RedesignResult } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToGenerativePart = (base64: string, mimeType: string) => {
  return {
    inlineData: {
      data: base64,
      mimeType,
    },
  };
};

export const redesignRoom = async (
  base64Image: string,
  mimeType: string,
  style: DesignStyle,
  prompt: string
): Promise<RedesignResult> => {
  try {
    const model = 'gemini-2.5-flash-image-preview';

    const fullPrompt = `Redesign this room in a ${style} style. ${prompt}`;
    const imagePart = fileToGenerativePart(base64Image, mimeType);

    const result = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          imagePart,
          { text: fullPrompt },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });
    
    let generatedImage: string | null = null;
    let generatedText: string | null = null;

    if (result.candidates && result.candidates[0] && result.candidates[0].content && result.candidates[0].content.parts) {
      for (const part of result.candidates[0].content.parts) {
        if (part.text) {
          generatedText = part.text;
        } else if (part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          const imageMimeType = part.inlineData.mimeType;
          generatedImage = `data:${imageMimeType};base64,${base64ImageBytes}`;
        }
      }
    }

    if (!generatedImage) {
        throw new Error("The AI did not return an image. Please try a different prompt or image.");
    }
    
    return { generatedImage, generatedText };

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to redesign room: ${error.message}`);
    }
    throw new Error("An unknown error occurred while redesigning the room.");
  }
};
