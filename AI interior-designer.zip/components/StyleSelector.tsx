
import React from 'react';
import { DESIGN_STYLES } from '../constants';
import { DesignStyle } from '../types';
import type { StyleOption } from '../types';

interface StyleSelectorProps {
  selectedStyle: DesignStyle | null;
  onStyleSelect: (style: DesignStyle) => void;
}

export const StyleSelector: React.FC<StyleSelectorProps> = ({ selectedStyle, onStyleSelect }) => {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-300 mb-2">2. Choose a design style</label>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {DESIGN_STYLES.map((style: StyleOption) => (
          <button
            key={style.name}
            onClick={() => onStyleSelect(style.name)}
            className={`flex items-center justify-center p-3 rounded-lg border-2 transition-all duration-200
              ${selectedStyle === style.name 
                ? 'bg-cyan-500/20 border-cyan-500 text-white' 
                : 'bg-gray-700/50 border-gray-600 hover:border-gray-500 text-gray-300'
              }`}
          >
            {style.icon}
            <span className="font-medium text-sm">{style.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
