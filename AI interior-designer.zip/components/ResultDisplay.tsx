
import React from 'react';

interface ResultDisplayProps {
  originalImage: string;
  generatedImage: string | null;
  generatedText: string | null;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ originalImage, generatedImage, generatedText }) => {
  
  const handleDownload = () => {
    if (generatedImage) {
        const link = document.createElement('a');
        link.href = generatedImage;
        link.download = 'redesigned-room.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
  };

  return (
    <div className="w-full animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex flex-col items-center">
          <h3 className="text-lg font-semibold text-gray-300 mb-2">Before</h3>
          <img src={originalImage} alt="Original room" className="rounded-lg shadow-lg w-full object-cover aspect-square" />
        </div>
        <div className="flex flex-col items-center">
          <h3 className="text-lg font-semibold text-cyan-400 mb-2">After</h3>
          {generatedImage ? (
            <img src={generatedImage} alt="Generated room" className="rounded-lg shadow-lg w-full object-cover aspect-square" />
          ) : (
            <div className="rounded-lg shadow-lg w-full object-cover aspect-square bg-gray-700 flex items-center justify-center">
              <p className="text-gray-400">No image generated.</p>
            </div>
          )}
        </div>
      </div>
      {generatedText && (
        <div className="mt-6 bg-gray-900/50 p-4 rounded-lg border border-gray-700">
          <h4 className="font-semibold text-cyan-400 mb-2">AI Suggestions:</h4>
          <p className="text-gray-300 text-sm">{generatedText}</p>
        </div>
      )}
      {generatedImage && (
         <button
            onClick={handleDownload}
            className="mt-6 w-full py-2 px-4 rounded-lg font-semibold transition-colors bg-gray-600 hover:bg-gray-500 text-white flex items-center justify-center"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            Download Image
        </button>
      )}
    </div>
  );
};
