
import React from 'react';

interface LoaderProps {
  large?: boolean;
}

export const Loader: React.FC<LoaderProps> = ({ large = false }) => {
  const sizeClasses = large ? 'h-10 w-10' : 'h-5 w-5';
  const borderClasses = large ? 'border-4' : 'border-2';

  return (
    <div className={`${sizeClasses} ${borderClasses} border-t-transparent border-solid animate-spin rounded-full border-white`}></div>
  );
};
