
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { StyleSelector } from './components/StyleSelector';
import { ResultDisplay } from './components/ResultDisplay';
import { Loader } from './components/Loader';
import { ErrorAlert } from './components/ErrorAlert';
import { redesignRoom } from './services/geminiService';
import { DesignStyle } from './types';
import type { RedesignResult } from './types';

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<DesignStyle | null>(null);
  const [userPrompt, setUserPrompt] = useState<string>('');
  const [result, setResult] = useState<RedesignResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (file: File | null) => {
    if (file) {
      setOriginalImage(file);
      setOriginalImageUrl(URL.createObjectURL(file));
      setResult(null); // Clear previous results
      setError(null);
    }
  };

  const fileToBase64 = (file: File): Promise<{ base64: string; mimeType: string }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve({ base64, mimeType: file.type });
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleSubmit = useCallback(async () => {
    if (!originalImage || !selectedStyle) {
      setError('Please upload an image and select a design style.');
      return;
    }

    setError(null);
    setIsLoading(true);
    setResult(null);

    try {
      const { base64, mimeType } = await fileToBase64(originalImage);
      const redesignResult = await redesignRoom(base64, mimeType, selectedStyle, userPrompt);
      setResult(redesignResult);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [originalImage, selectedStyle, userPrompt]);

  const isSubmitDisabled = !originalImage || !selectedStyle || isLoading;

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-4 sm:p-6 lg:p-8">
      <div className="container mx-auto max-w-7xl">
        <Header />
        <main className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls Column */}
          <div className="bg-gray-800/50 p-6 rounded-2xl shadow-2xl flex flex-col space-y-6 backdrop-blur-sm border border-gray-700">
            <ImageUploader onImageChange={handleImageChange} imageUrl={originalImageUrl} />
            <StyleSelector selectedStyle={selectedStyle} onStyleSelect={setSelectedStyle} />
            <div>
              <label htmlFor="user-prompt" className="block text-sm font-medium text-gray-300 mb-2">
                3. Add specific instructions (optional)
              </label>
              <textarea
                id="user-prompt"
                rows={3}
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-shadow"
                placeholder="e.g., add a large plant in the corner, change the wall color to beige..."
              />
            </div>
            <button
              onClick={handleSubmit}
              disabled={isSubmitDisabled}
              className={`w-full py-3 px-4 rounded-lg text-lg font-semibold transition-all duration-300 flex items-center justify-center
                ${isSubmitDisabled 
                  ? 'bg-gray-600 cursor-not-allowed text-gray-400' 
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg hover:shadow-cyan-500/50'
                }`}
            >
              {isLoading ? (
                <Loader />
              ) : (
                <>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                  Redesign My Room
                </>
              )}
            </button>
          </div>

          {/* Results Column */}
          <div className="bg-gray-800/50 p-6 rounded-2xl shadow-2xl flex flex-col items-center justify-center min-h-[400px] backdrop-blur-sm border border-gray-700">
            {isLoading && (
              <div className="text-center">
                <Loader large={true} />
                <p className="mt-4 text-lg text-gray-300 animate-pulse">Our AI is redesigning your room...</p>
                <p className="mt-2 text-sm text-gray-400">This can take a moment.</p>
              </div>
            )}
            {error && !isLoading && <ErrorAlert message={error} />}
            {!isLoading && !error && result && originalImageUrl && (
              <ResultDisplay
                originalImage={originalImageUrl}
                generatedImage={result.generatedImage}
                generatedText={result.generatedText}
              />
            )}
            {!isLoading && !error && !result && (
               <div className="text-center text-gray-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                <h3 className="mt-4 text-lg font-medium text-gray-400">Your redesigned room will appear here</h3>
                <p className="mt-1 text-sm">Follow the steps on the left to get started.</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
